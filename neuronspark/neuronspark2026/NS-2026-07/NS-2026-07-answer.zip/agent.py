from __future__ import annotations

import math
from typing import Any


def _norm2(x: float, y: float) -> float:
    return math.sqrt(x * x + y * y)


def _normalize(x: float, y: float) -> tuple[float, float]:
    n = _norm2(x, y)
    if n < 1e-9:
        return 0.0, 0.0
    return x / n, y / n


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


class Agent:
    """NS-2026-07 controller v7 (best version).

    Key innovations:
    - Damage-aware force limits based on fragility threshold
    - Conservative finish thresholds (accounts for observation noise)
    - Front-loaded tool taps with interleaved continuation
    - Balanced obstacle avoidance with reactive recovery
    - Corridor handling with lateral dampening
    - Slip recovery via safe brace/stabilize primitives
    """

    def reset(self, task_info: dict) -> None:
        self.task_type = task_info.get("task_type", "nonprehensile_relocation")
        self.tool_axis = task_info.get("tool_goal", {}).get("axis", [1.0, 0.0])
        self.tool_need = float(task_info.get("tool_goal", {}).get("progress", 0.0))
        self.reserved = task_info.get("resource_constraint", {}).get("reserve_fingers", [])
        self.max_peak_force = float(task_info.get("resource_constraint", {}).get("max_peak_force", 0.8))
        self.scene = task_info.get("scene_context", {})
        self.obstacles = self.scene.get("obstacles", []) if isinstance(self.scene, dict) else []
        self.corridor = self.scene.get("corridor", {}) if isinstance(self.scene, dict) else {}

        obj = task_info.get("object", {})
        self.fragility = float(obj.get("fragility", 0.0))
        self.mass = float(obj.get("mass", 1.0))
        self.compliance = float(obj.get("compliance", 0.3))
        self.obj_size = float(obj.get("size", 0.1))

        # Damage threshold: normal above this causes damage
        self.dmg_thresh = 1.05 - 0.72 * self.fragility
        # Safe force limits for each effector
        self.safe_palm = min(0.92, self.dmg_thresh / 1.15)
        self.safe_index = min(0.95, self.dmg_thresh / 0.98)
        self.safe_thumb = min(0.92, self.dmg_thresh / 1.05)

        self.has_stages = bool(task_info.get("stage_goals"))
        self.taps_done = 0
        self.taps_needed = self._calc_taps()
        self.phase = "brace"
        self.brace_done = 0
        self.stuck = 0
        self.last_dist = None

        self._batch_agents = None

    def reset_batch(self, task_infos: list[dict]) -> None:
        self._batch_agents = [Agent() for _ in task_infos]
        for a, t in zip(self._batch_agents, task_infos):
            a.reset(t)

    def act_batch(self, observations: list[dict]) -> list[dict]:
        if self._batch_agents is None:
            raise RuntimeError("reset_batch must be called before act_batch")
        return [self._batch_agents[int(o.get("batch_index", i))].act(o)
                for i, o in enumerate(observations)]

    def _calc_taps(self) -> int:
        if self.task_type == "nonprehensile_relocation":
            return 0
        per_tap = 0.048
        if self.task_type == "tool_use":
            target = max(0.08, self.tool_need) * 0.84
            return int(_clamp(math.ceil(target / per_tap), 9, 24))
        else:  # resource_sequence
            target = max(0.08, self.tool_need) * 0.84
            return int(_clamp(math.ceil(target / per_tap), 9, 22))

    def _force(self, base: float, role: str, damage_risk: float) -> float:
        if role == "palm":
            f = min(base, self.safe_palm)
        elif role == "tap":
            f = min(base, self.safe_index)
        elif role == "pivot":
            f = min(base, self.safe_thumb)
        else:
            f = min(base, self.safe_palm)
        if damage_risk > 0.15:
            f *= max(0.50, 1.0 - damage_risk * 0.55)
        f = min(f, self.max_peak_force + 0.06)
        return _clamp(f, 0.05, 1.0)

    def _avoid(self, dx: float, dy: float, obs: dict) -> tuple[float, float]:
        pose = obs.get("object_pose_estimate", {})
        ox, oy = float(pose.get("x", 0.0)), float(pose.get("y", 0.0))
        ax, ay = dx, dy

        for o in self.obstacles:
            try:
                cx = float(o.get("x", 0.0))
                cy = float(o.get("y", 0.0))
                r = float(o.get("radius", 0.08))
            except (KeyError, TypeError, ValueError):
                continue
            ddx = ox - cx
            ddy = oy - cy
            d = _norm2(ddx, ddy)
            danger = r + max(0.025, self.obj_size * 0.22) + 0.06
            if d < danger + 0.16 and d > 1e-6:
                ndx, ndy = _normalize(ddx, ddy)
                if d < danger:
                    scale = 0.8 + (danger - d) * 4.0
                else:
                    margin = d - danger
                    scale = 0.4 * (1.0 - margin / 0.16)
                ax += ndx * scale
                ay += ndy * scale

        if self.corridor:
            try:
                w = float(self.corridor.get("width", 0.0))
                if w > 0:
                    ca = self.corridor.get("axis", [1.0, 0.0])
                    cax, cay = _normalize(float(ca[0]), float(ca[1]))
                    offset = float(self.corridor.get("offset", 0.0))
                    lat = -cay * ox + cax * oy - offset
                    half = w * 0.5
                    margin = half - abs(lat)
                    if margin < 0.10:
                        sign = -1.0 if lat > 0 else 1.0
                        strength = 0.5 * max(0.0, 1.0 - margin / 0.10)
                        ax += (-cay) * sign * strength
                        ay += cax * sign * strength
                    if margin < 0.12:
                        along = ax * cax + ay * cay
                        perp = ax * (-cay) + ay * cax
                        perp *= 0.4
                        ax = along * cax + perp * (-cay)
                        ay = along * cay + perp * cax
            except Exception:
                pass

        return _normalize(ax, ay)

    def _can_finish(self, obs: dict) -> bool:
        state = obs["low_dim_state"]["values"]
        df = _norm2(float(state[3]), float(state[4]))
        af = abs(float(state[5]))
        if df >= 0.062 or af >= 0.24:
            return False
        sc = obs.get("stage_context", {})
        if sc.get("enabled", False) and float(sc.get("completion_fraction", 0)) < 0.999:
            return False
        if self.task_type != "nonprehensile_relocation":
            if self.taps_done < self.taps_needed * 0.72:
                return False
        return True

    def act(self, observation: dict) -> dict:
        step = int(observation["step"])
        remaining = int(observation.get("remaining_steps", 128 - step))
        state = observation["low_dim_state"]["values"]

        dx, dy, dtheta = float(state[0]), float(state[1]), float(state[2])
        dx_f, dy_f, dtheta_f = float(state[3]), float(state[4]), float(state[5])
        contact = float(state[9])
        slip_risk = float(state[10])
        damage_risk = float(observation.get("contact_summary", {}).get("damage_risk", 0.0))

        dist = _norm2(dx, dy)
        angle = abs(dtheta)
        dist_f = _norm2(dx_f, dy_f)
        angle_f = abs(dtheta_f)
        sc = observation.get("stage_context", {})

        # ===== FINISH =====
        if self._can_finish(observation):
            return {"primitive": "finish", "finger": "palm", "force": 0.0, "direction": [0.0, 0.0]}

        if remaining <= 1:
            if dist_f < 0.13 and angle_f < 0.55:
                return {"primitive": "finish", "finger": "palm", "force": 0.0, "direction": [0.0, 0.0]}
            nfx, nfy = _normalize(dx_f, dy_f)
            nfx, nfy = self._avoid(nfx, nfy, observation)
            return {"primitive": "push", "finger": "palm",
                    "force": self._force(0.82, "palm", damage_risk), "direction": [nfx, nfy]}

        # ===== CONTACT EMERGENCY =====
        if contact < 0.06:
            return {"primitive": "stabilize", "finger": "palm", "force": 0.45, "direction": [0.0, 0.0]}

        # ===== BRACE PHASE =====
        if self.phase == "brace":
            self.brace_done += 1
            if (self.brace_done >= 1 and contact >= 0.22) or self.brace_done >= 2:
                self.phase = "tool" if self.taps_needed > 0 else "move"
            return {"primitive": "brace", "finger": "palm", "force": 0.38, "direction": [0.0, 0.0]}

        # ===== CONTACT RECOVERY =====
        if contact < 0.13 or (slip_risk > 0.86 and contact < 0.26):
            return {"primitive": "brace", "finger": "palm", "force": 0.36, "direction": [0.0, 0.0]}

        # ===== TOOL PHASE =====
        if self.phase == "tool":
            if self.taps_done >= self.taps_needed:
                self.phase = "move"
            else:
                if contact < 0.20:
                    return {"primitive": "brace", "finger": "palm", "force": 0.33, "direction": [0.0, 0.0]}
                self.taps_done += 1
                ax, ay = _normalize(float(self.tool_axis[0]), float(self.tool_axis[1]))
                finger = self.reserved[0] if (self.task_type == "resource_sequence" and self.reserved) else "index"
                return {"primitive": "tap", "finger": finger,
                        "force": self._force(0.88, "tap", damage_risk), "direction": [ax, ay]}

        # ===== MOVE PHASE =====
        # Extra taps
        if self.taps_done < self.taps_needed and step % 4 == 0 and remaining > 10 and contact > 0.20:
            self.taps_done += 1
            ax, ay = _normalize(float(self.tool_axis[0]), float(self.tool_axis[1]))
            finger = self.reserved[0] if (self.task_type == "resource_sequence" and self.reserved) else "index"
            return {"primitive": "tap", "finger": finger,
                    "force": self._force(0.85, "tap", damage_risk), "direction": [ax, ay]}

        # Stuck detection
        if self.last_dist is not None and dist > 0.10:
            self.stuck = self.stuck + 1 if abs(dist - self.last_dist) < 0.003 else max(0, self.stuck - 2)
        self.last_dist = dist

        if self.stuck > 6:
            self.stuck = 0
            nx, ny = _normalize(dx, dy)
            nx, ny = self._avoid(nx, ny, observation)
            return {"primitive": "drag", "finger": "index",
                    "force": self._force(0.75, "palm", damage_risk), "direction": [nx, ny]}

        # === ROTATION ===
        if angle > 0.36 and dist < 0.22:
            sign = 1.0 if dtheta >= 0 else -1.0
            f = 0.86 if self.mass > 1.2 else 0.80
            return {"primitive": "pivot", "finger": "thumb",
                    "force": self._force(f, "pivot", damage_risk), "direction": [sign, 0.0]}

        if angle > 0.26 and dist > 0.12:
            nx, ny = _normalize(dx, dy)
            nx, ny = self._avoid(nx, ny, observation)
            if (nx + ny >= 0) == (dtheta >= 0):
                return {"primitive": "roll", "finger": "palm",
                        "force": self._force(0.74, "palm", damage_risk), "direction": [nx, ny]}
            else:
                sign = 1.0 if dtheta >= 0 else -1.0
                return {"primitive": "pivot", "finger": "thumb",
                        "force": self._force(0.80, "pivot", damage_risk), "direction": [sign, 0.0]}

        # === TRANSLATION ===
        if dist > 0.088:
            nx, ny = _normalize(dx, dy)
            nx, ny = self._avoid(nx, ny, observation)
            if self.mass > 1.3:
                base = 0.88
            elif dist > 0.28:
                base = 0.82
            elif dist > 0.15:
                base = 0.74
            else:
                base = 0.65
            return {"primitive": "push", "finger": "palm",
                    "force": self._force(base, "palm", damage_risk), "direction": [nx, ny]}

        # === FINE ROTATION ===
        if angle > 0.12:
            sign = 1.0 if dtheta >= 0 else -1.0
            return {"primitive": "pivot", "finger": "thumb",
                    "force": self._force(0.55, "pivot", damage_risk), "direction": [sign, 0.0]}

        # === NEAR TARGET ===
        stages_ok = not sc.get("enabled", False) or float(sc.get("completion_fraction", 0)) >= 0.999
        tool_ok = self.task_type == "nonprehensile_relocation" or self.taps_done >= self.taps_needed * 0.65
        if dist_f < 0.065 and angle_f < 0.26 and stages_ok and tool_ok:
            return {"primitive": "finish", "finger": "palm", "force": 0.0, "direction": [0.0, 0.0]}

        if dist > 0.02:
            nx, ny = _normalize(dx, dy)
        else:
            nx, ny = _normalize(dx_f, dy_f)
        nx, ny = self._avoid(nx, ny, observation)
        return {"primitive": "push", "finger": "palm",
                "force": self._force(0.42, "palm", damage_risk), "direction": [nx, ny]}
